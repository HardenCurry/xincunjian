"""empty message

Revision ID: 87cdf10e692c
Revises: 
Create Date: 2023-05-28 22:16:05.011264

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '87cdf10e692c'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
